
export { default as TeacherAssessment } from './TeacherAssessment';